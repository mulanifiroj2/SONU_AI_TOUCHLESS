package com.sonu.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var preview: PreviewView
    private lateinit var status: TextView
    private lateinit var speechText: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private var handLandmarker: HandLandmarker? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var lastGestureAt = 0L
    private var previousWristX: Float? = null
    private var previousWristY: Float? = null
    private var previousPalmWidth = 0f
    private var wakeMode = false
    private var waitingCommand = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        requestPermissionsIfNeeded()
        prepareHandModel()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.rgb(9, 10, 16))
        }
        val title = TextView(this).apply {
            text = "SONU AI 2.0"; textSize = 30f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(0, 10, 0, 2)
        }
        val subtitle = TextView(this).apply {
            text = "VOICE + AIR FINGER + HAND GESTURE"; textSize = 11f
            gravity = Gravity.CENTER; setTextColor(Color.rgb(255, 65, 75)); setPadding(0, 0, 0, 12)
        }
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        status = TextView(this).apply {
            text = "Camera and microphone permission required"
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(Color.LTGRAY); setPadding(4, 10, 4, 10)
        }
        speechText = TextView(this).apply {
            text = "Say “Hello SONU” or tap the microphone"
            textSize = 13f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); setPadding(4, 6, 4, 10)
        }
        val mic = button("🎙 TAP TO SPEAK") { listenOnce() }
        val wake = button("🔴 START HELLO SONU MODE") { toggleWake() }
        val accessibility = button("ENABLE TOUCHLESS CONTROL") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            say("Accessibility settings khol raha hoon. SONU AI service manually enable karein.")
        }
        val playPause = button("▶ PLAY / PAUSE") { sendMediaToggle() }
        val stop = button("STOP CAMERA / WAKE MODE") { stopCameraAndWake() }
        root.addView(title); root.addView(subtitle)
        root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(status); root.addView(speechText)
        root.addView(mic); root.addView(wake); root.addView(accessibility); root.addView(playPause); root.addView(stop)
        setContentView(root)
        startCameraWhenAllowed()
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(150, 24, 35))
        setOnClickListener { action() }
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.CAMERA)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 10)
    }

    private fun prepareHandModel() {
        try {
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setResultListener { result, _ -> onHandResult(result) }
                .setErrorListener { e -> runOnUiThread { status.text = "Hand model error: ${e.message}" } }
                .build()
            handLandmarker = HandLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            status.text = "Hand model missing. Rebuild after downloading hand_landmarker.task; see README."
        }
    }

    private fun startCameraWhenAllowed() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val previewUseCase = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(cameraExecutor) { image ->
                analyzeFrame(image)
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, previewUseCase, analysis)
                status.text = "Air gesture camera active. Keep app open and visible."
            } catch (e: Exception) { status.text = "Camera start failed: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val bitmap = imageProxyToBitmap(image) ?: return
            val rotated = android.graphics.Matrix().let { m ->
                m.postRotate(image.imageInfo.rotationDegrees.toFloat())
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true)
            }
            val mpImage = BitmapImageBuilder(rotated).build()
            handLandmarker?.detectAsync(mpImage, System.currentTimeMillis())
            bitmap.recycle()
            if (rotated !== bitmap) rotated.recycle()
        } catch (_: Exception) {
        } finally { image.close() }
    }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
        val y = image.planes[0].buffer
        val u = image.planes[1].buffer
        val v = image.planes[2].buffer
        val ySize = y.remaining(); val uSize = u.remaining(); val vSize = v.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        y.get(nv21, 0, ySize)
        // Interleave VU for NV21
        val uvPixelStride = image.planes[1].pixelStride
        val uvRowStride = image.planes[1].rowStride
        var offset = ySize
        val uBytes = ByteArray(uSize); val vBytes = ByteArray(vSize)
        u.get(uBytes); v.get(vBytes)
        for (row in 0 until image.height / 2) {
            for (col in 0 until image.width / 2) {
                val ui = row * uvRowStride + col * uvPixelStride
                val vi = row * image.planes[2].rowStride + col * image.planes[2].pixelStride
                if (vi < vBytes.size && ui < uBytes.size && offset + 1 < nv21.size) {
                    nv21[offset++] = vBytes[vi]; nv21[offset++] = uBytes[ui]
                }
            }
        }
        val yuv = android.graphics.YuvImage(nv21, android.graphics.ImageFormat.NV21, image.width, image.height, null)
        val out = java.io.ByteArrayOutputStream()
        yuv.compressToJpeg(android.graphics.Rect(0, 0, image.width, image.height), 70, out)
        return BitmapFactory.decodeByteArray(out.toByteArray(), 0, out.size())
    }

    private fun onHandResult(result: HandLandmarkerResult) {
        if (result.landmarks().isEmpty()) return
        val lm = result.landmarks()[0]
        if (lm.size < 21) return
        val now = System.currentTimeMillis()
        val wrist = lm[0]
        val thumb = lm[4]; val index = lm[8]
        val pinch = hypot(thumb.x() - index.x(), thumb.y() - index.y()) < 0.055f
        val indexUp = lm[8].y() < lm[6].y()
        val middleUp = lm[12].y() < lm[10].y()
        val ringUp = lm[16].y() < lm[14].y()
        val pinkyUp = lm[20].y() < lm[18].y()
        val openPalm = indexUp && middleUp && ringUp && pinkyUp
        val fist = !indexUp && !middleUp && !ringUp && !pinkyUp
        val oldX = previousWristX
        val oldY = previousWristY
        previousWristX = wrist.x(); previousWristY = wrist.y()
        if (now - lastGestureAt < 1100) return
        when {
            pinch -> { lastGestureAt = now; runOnUiThread { doTap(); status.text = "Air pinch: tap" } }
            oldX != null && abs(wrist.x() - oldX) > 0.20f -> {
                lastGestureAt = now
                runOnUiThread { doSwipe(if (wrist.x() < oldX) "LEFT" else "RIGHT") }
            }
            oldY != null && abs(wrist.y() - oldY) > 0.20f -> {
                lastGestureAt = now
                runOnUiThread { doSwipe(if (wrist.y() < oldY) "UP" else "DOWN") }
            }
            openPalm -> { lastGestureAt = now; runOnUiThread { sendMediaToggle(); status.text = "Open palm: Play/Pause" } }
            fist -> { lastGestureAt = now; runOnUiThread { doBack(); status.text = "Fist: Back" } }
        }
    }

    private fun doTap() {
        val service = SonuAccessibilityService.instance
        if (service == null) {
            status.text = "Tap gesture ke liye Accessibility service enable karo."
            return
        }
        // Center-screen tap: pinch gesture acts as a tap at screen center.
        service.tap(resources.displayMetrics.widthPixels / 2f, resources.displayMetrics.heightPixels / 2f)
    }

    private fun doSwipe(direction: String) {
        val service = SonuAccessibilityService.instance
        if (service == null) { status.text = "Swipe ke liye Accessibility service enable karo."; return }
        val dx = when(direction) { "LEFT" -> -420f; "RIGHT" -> 420f; else -> 0f }
        val dy = when(direction) { "UP" -> -650f; "DOWN" -> 650f; else -> 0f }
        service.swipe(dx, dy)
        status.text = "Air swipe $direction"
    }

    private fun doBack() {
        val service = SonuAccessibilityService.instance
        if (service != null) service.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
        else status.text = "Back gesture ke liye Accessibility service enable karo."
    }

    private fun sendMediaToggle() {
        val down = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        val up = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.dispatchMediaKeyEvent(down); am.dispatchMediaKeyEvent(up)
        status.text = "Media Play/Pause command sent"
    }

    private fun listenOnce() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 11); return
        }
        startSpeech(false)
    }

    private fun toggleWake() {
        wakeMode = !wakeMode
        if (wakeMode) startSpeech(true) else recognizer?.cancel()
        status.text = if (wakeMode) "Wake mode: app open hone par “Hello SONU” bolo." else "Wake mode stopped."
    }

    private fun startSpeech(isWake: Boolean) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Speech recognition unavailable"; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { if (isWake && wakeMode) window.decorView.postDelayed({ startSpeech(true) }, 800) }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                speechText.text = "Heard: $text"
                val normalized = text.lowercase(Locale.ROOT)
                if (isWake && !waitingCommand) {
                    if (normalized.contains("hello sonu") || normalized.contains("हेलो सोनू")) {
                        waitingCommand = true; say("Haan, boliye")
                    }
                    if (wakeMode) window.decorView.postDelayed({ startSpeech(true) }, 1500)
                } else {
                    waitingCommand = false; handleVoiceCommand(normalized)
                    if (isWake && wakeMode) window.decorView.postDelayed({ startSpeech(true) }, 1500)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(intent)
    }

    private fun handleVoiceCommand(c: String) {
        when {
            c.contains("play") || c.contains("pause") || c.contains("gaana") || c.contains("music") -> sendMediaToggle()
            c.contains("back") || c.contains("पीछे") -> doBack()
            c.contains("left") || c.contains("बाएं") -> doSwipe("LEFT")
            c.contains("right") || c.contains("दाएं") -> doSwipe("RIGHT")
            c.contains("upar") || c.contains("ऊपर") -> doSwipe("UP")
            c.contains("neeche") || c.contains("नीचे") -> doSwipe("DOWN")
            c.contains("youtube") -> openPackage("com.google.android.youtube")
            c.contains("maps") || c.contains("map") -> openPackage("com.google.android.apps.maps")
            c.contains("wifi") -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            c.contains("bluetooth") -> startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            c.contains("setting") -> startActivity(Intent(Settings.ACTION_SETTINGS))
            else -> say("Ye command abhi supported nahi hai.")
        }
    }

    private fun openPackage(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else say("App nahi mila.")
    }

    private fun say(message: String) {
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "sonu")
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN") }

    private fun stopCameraAndWake() {
        wakeMode = false; recognizer?.cancel()
        val provider = ProcessCameraProvider.getInstance(this)
        provider.addListener({ provider.get().unbindAll(); status.text = "Camera stopped." }, ContextCompat.getMainExecutor(this))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startCameraWhenAllowed()
            if (requestCode == 11) listenOnce()
        } else Toast.makeText(this, "Permission required for selected feature", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        wakeMode = false
        recognizer?.destroy()
        handLandmarker?.close()
        cameraExecutor.shutdown()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
