package com.sonu.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class SonuAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun tap(x: Float = 540f, y: Float = 960f) = gesture {
        moveTo(x, y); lineTo(x, y)
    }
    fun swipe(dx: Float, dy: Float) = gesture {
        moveTo(540f, 960f); lineTo(540f + dx, 960f + dy)
    }
    private fun gesture(build: Path.() -> Unit) {
        val path = Path().apply(build)
        val stroke = GestureDescription.StrokeDescription(path, 0, 220)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    companion object {
        @Volatile var instance: SonuAccessibilityService? = null
    }
    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
}
