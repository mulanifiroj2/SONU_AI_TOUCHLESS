# SONU AI 2.0 — Touchless Android source

Includes:
- Tap-to-speak voice activation
- “Hello SONU” wake phrase while app is open and visible
- Front-camera hand tracking using MediaPipe Tasks Vision
- Air pinch = center-screen tap
- Horizontal hand movement = left/right swipe
- Vertical hand movement = up/down swipe
- Open palm = media Play/Pause
- Closed fist = Back
- Accessibility service for user-approved gestures

## Important
This is a source project, not a tested/signed APK. It requires build + real-device testing on OPPO Reno 11.
Air gestures run only while this app is open and camera permission is granted. Android may restrict camera use in background/lock screen.
Accessibility must be enabled manually by the user in Settings > Accessibility > Downloaded/Installed apps > SONU AI Touchless. This permission can control gestures across apps, so enable only if you trust the app.
Media Play/Pause is sent as a standard media key; whether it works depends on the foreground media app.
Gesture detection thresholds may need calibration. Lighting, camera position, hand distance and phone orientation affect accuracy.
The current air-pinch tap uses screen center; it does not track an arbitrary on-screen cursor. Open palm is Play/Pause. No push-forward gesture is assigned in this version.
Speech recognition depends on the Android speech recognition provider and may use internet.
No camera frames or voice recordings are uploaded by this app.

## Model asset
The MediaPipe hand landmark model is downloaded by the included GitHub Actions workflow from Google's public model storage. The workflow places it in `app/src/main/assets/hand_landmarker.task` before building.

## Build on GitHub
1. Create a GitHub repository.
2. Upload all files from this ZIP, keeping folder structure.
3. Open Actions and run `Build SONU AI APK`.
4. Download artifact `SONU-AI-debug-apk` from the completed workflow run.
5. Extract artifact and install `app-debug.apk` on your own phone.

You can also open the folder in Android Studio (JDK 17, Android SDK 35) and build `assembleDebug`.

## Safety
Use gestures only when stationary. Do not use camera gesture control while driving. For car use, configure and test only when parked. Payment, delete, send and other sensitive actions should always require visible confirmation.
